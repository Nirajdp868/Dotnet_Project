﻿using MiniProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MiniProject.Controllers
{
    public class UserController : Controller
    {

        TvmDBEntities entity = new TvmDBEntities();
        LogicalCode logicalcode=new LogicalCode();
        public ActionResult Index()
        {

            return View("Login");
        }

        // GET: User

        public ActionResult Login(User us)
        {

            List<User> users = logicalcode.getAll();

            User u = null;
            u=(from h in users
                      where h.Email.ToLower() == us.Email.ToLower() select h).FirstOrDefault();

            
                if (u != null)
                {
                    if (u.Password == us.Password)
                    {
                        if (u.Role!= "Admin")
                        {
                            //return View("Student/Index");
                           FormsAuthentication.SetAuthCookie(u.Email, false);
                           return RedirectToAction("Index", "Student");
                            //  return View("Separate");
                        }
                        else
                        {
                            return Redirect("/User/Data");
                        }
                    }
                    else
                    {
                        return Redirect("/User/Index");
                    }

                }
        
            
            return View("Register");
        }

        public ActionResult Data()
        {
            List<User> users = logicalcode.getAll();
            return View("ViewAll",users);  
        }

       
        public ActionResult Register(User user)
        {

            User UpdatedUser = logicalcode.Hashing(user);

            entity.Users.Add(UpdatedUser);
            int data = entity.SaveChanges();
            if (data != 0)
            {
                return Redirect("/User/Index");
            }
            return View("Register");

        }

        public ActionResult Logout()
        {

            FormsAuthentication.SignOut();
            return View("Logout");

        }


        public ActionResult edit(int id) {
            User update=entity.Users.Find(id);
            return View("Edit",update);
        }

        public ActionResult Afteredit(User u)
        {
          User updatable= entity.Users.Find(u.Id);
            updatable.Age = u.Age;
            updatable.Name = u.Name;    
            updatable.Address = u.Address;
            int id=entity.SaveChanges();
            if (id != 0)
            return Redirect("/User/Data");
            return View("edit");
        }

        public ActionResult Delete(int id)
        {
            User delete = entity.Users.Find(id);
            entity.Users.Remove(delete);
            int data=entity.SaveChanges();
            if (data != 0)  
            return Redirect("/User/Data");
            return View("Delete");
        }


        public ActionResult LoginForAdmin()
        {
            return RedirectToAction("Index", "Student");
        }


    }

    public class LogicalCode
    {
        TvmDBEntities entity = new TvmDBEntities();
        public List<User> getAll()
        {

            List<User> user = entity.Users.ToList();
            return user;
        }
        public User Hashing(User user)//for only id increament ...
        {
            List<User> users = getAll();
            int count = 1;
            foreach (User u in users)
            {
                if (users.Count == count)
                {
                    user.Id = u.Id + 1;// to make id as last element id+1
                    break;
                }
                count++;

            }
            return user;
        }
    }
}

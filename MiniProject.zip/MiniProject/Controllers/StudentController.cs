﻿using MiniProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MiniProject.Controllers
{
    [HandleError(ExceptionType = typeof(Exception), View = "Error")]//error handling
    public class StudentController : Controller
    {
        TvmDBEntities entity = new TvmDBEntities();
        MyClass obj= new MyClass();
        // GET: Student
        public ActionResult Index()
        {
           
            return View("Show", entity.Students.ToList());
        }


        public ActionResult Create()
        {
            return View("Create");
        }


        public ActionResult AfterCreate(Student st)
        {
            List<Student> stud = entity.Students.ToList();//get all student data 

            foreach (Student s1 in stud)
            {

                if (st.Id == s1.Id)///it iterate upto the condition as st.Id!=s1.id;
                {
                    st.Id = obj.hashing(st.Id);//create hashing function externally to check that id is not present
                }    
            }
            st = obj.CheckAndUpdateDefaultFee(st);//update default Fees of coures

            Student s = entity.Students.Add(st);
            int res = entity.SaveChanges();
            if (res > 0)
            {
                return Redirect("/Student/Index");
            }
            else
            {
                return View("Create");
            }

        }
     
        public ActionResult Edit(int id)
        {
            Student s1 = entity.Students.Find(id);
            return View("Edit", s1);
        }


        public ActionResult AfterEdit(Student s)
        {
            Student s1 = entity.Students.Find(s.Id);
            s1.Name = s.Name;
            s1.Age_ = s.Age_;
            s1.CName = s.CName;
            s1.Address = s.Address;
            s1.Project = s.Project;
           
           s1 = obj.CheckAndUpdateDefaultFee(s1);


            int data = entity.SaveChanges();
            if (data > 0)
            {
                return Redirect("/Student/Index");
            }
            else
            {
                return View("Edit");
            }
        }
        public ActionResult Delete(int Id)
        {
            Student s = entity.Students.Find(Id);
            Student std = entity.Students.Remove(s);
            entity.SaveChanges();
            if (std != null)
            {
                return Redirect("/Student/Index");
            }
            else
            {
                return View("Delete");
            }

        }
   
        public ActionResult jspTech()
        {
            string s = "JSP View Technology";
            List<Student> studs = obj.SpecificStudents(s);
            return View("SpecificTech", studs);
        }

        public ActionResult spring()
        {
            string s = "Spring";
            List<Student> studs = obj.SpecificStudents(s);
            return View("SpecificTech", studs);

        }
        public ActionResult springboot()
        {
            string s = "SpringBoot";
            List<Student> studs = obj.SpecificStudents(s);
            return View("SpecificTech", studs);

        }

        public ActionResult android()
        {
            string s = "Android";
            List<Student> studs = obj.SpecificStudents(s);//method which returns secific list of student 
            return View("SpecificTech", studs);

        }

        public ActionResult dotnet()
        {
            string s = "Dotnet";
            List<Student> studs = obj.SpecificStudents(s);
            return View("SpecificTech", studs);

        }


        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Logout", "User");
        }


        public ActionResult ShowError()
        {
            int x = 0;
            int y = 5;
            int d = y / x;
            return View("Index");//dummy error checking 

        }
    }

    class MyClass
    {
        TvmDBEntities entity = new TvmDBEntities();

        public List<Student> GetAllStudents()
        {
            List<Student> s = entity.Students.ToList();
            return s;
        }
        public List<Student> SpecificStudents(string s)
        {
            List<Student> st = GetAllStudents();
            List<Student> studs = (from a in st where a.Project == s select a).ToList();
            return studs;//logic for jsp /spring/springboot //separation of code 
        }



        public int hashing(int id)//to create different id other than present one 
        {
            return id + 1;//increment by 1 if id is already is present 
        }

        public Student CheckAndUpdateDefaultFee(Student st)
        {
            if (st.CName == "CDAC")
            {
                st.TotalFee = 100000;

            }
            else if (st.CName == "DBDA")
            {
                st.TotalFee = 150000;
            }
            else
            {
                st.TotalFee = 120000;
            }

            st.RemainingFee = st.TotalFee;//initial Remaining Fee
            st.CourseFee = 0;//s

            return st;
        }
    }
}
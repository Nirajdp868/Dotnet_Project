﻿using MiniProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MiniProject.Controllers
{ 

    public class FeeController : Controller
    {

        TvmDBEntities entity = new TvmDBEntities();
        // GET: Fee
        public ActionResult Index()
        {
            return View("PayFee");
        }


        public ActionResult Create(Student s)
        {
            LogicalCodes logicalCodes= new LogicalCodes();
            List<Student> details = logicalCodes.GetDetails();
            Student sb = (from h in details where h.Name.ToLower() == s.Name.ToLower() select h).FirstOrDefault();
           
            if (sb!=null)
            {
                return View("UpdateFee", sb);
            }
            else
            {
                return View("NotFound", s);
            }      
        }

        public ActionResult AfterUpdate(Student s) {
           Student st= entity.Students.Find(s.Id);
            int check = (int)(st.CourseFee + s.CourseFee);
            if (s.CourseFee <= st.TotalFee && check<=st.TotalFee)//if the paid fee is not more than TotalFee
            {   
                st.CourseFee += s.CourseFee;//update coures fee
            }
               
            if (st.TotalFee!=null && st.CourseFee<=st.TotalFee)
            {
                st.RemainingFee = st.TotalFee - st.CourseFee;//update Remaining fee
            }
            
           int res= entity.SaveChanges();
            return RedirectToAction("Index", "Student");
        }

    }

    public class LogicalCodes {

        TvmDBEntities entity = new TvmDBEntities();
        public List<Student> GetDetails() {

            List<Student> s=entity.Students.ToList();

            return s;
        }
}

}